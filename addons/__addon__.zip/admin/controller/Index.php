<?php
/**
 * Created by PhpStorm.
 * Script Name: Index.php
 * Create: 2023/5/23 11:03
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace addons\__ADDON_NAME__\admin\controller;

class Index extends Base
{
    public function welcome(){
        return $this->show();
    }

    public function index(){
        return $this->show();
    }
}