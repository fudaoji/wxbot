<?php
/**
 * Created by PhpStorm.
 * Script Name: ListBuilder.php
 * Create: 9/21/22 11:09 PM
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace addons\__ADDON_NAME__\admin\controller;

use app\addon\AddonListBuilder;

class ListBuilder extends AddonListBuilder
{
    public function initialize()
    {
        parent::initialize();
        $this->assign['page_jump_type'] = session('page_jump_type'); // iframe|normal;
        $this->assign['current_menu'] = $this->module .'/'. $this->controller .'/'. $this->action;
    }
}