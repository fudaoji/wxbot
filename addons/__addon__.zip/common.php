<?php
/**
 * Created by PhpStorm.
 * Script Name: common.php
 * Create: 2023/5/23 16:57
 * Description: 应用插件的公共函数
 * Author: fudaoji<fdj@kuryun.cn>
 */


