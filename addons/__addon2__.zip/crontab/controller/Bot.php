<?php
/**
 * Created by PhpStorm.
 * Script Name: Bot.php
 * Create: 2023/5/24 11:32
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace addons\__ADDON_NAME__\crontab\controller;

use app\crontab\controller\Base;

class Bot extends Base
{
    /**
     * 分钟任务
     * Author: fudaoji<fdj@kuryun.cn>
     */
    public function minuteTask(){
        //todo
    }
}