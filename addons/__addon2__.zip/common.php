<?php
/**
 * Created by PhpStorm.
 * Script Name: common.php
 * Create: 2023/5/23 16:57
 * Description: 应用插件的公共函数
 * Author: fudaoji<fdj@kuryun.cn>
 */

$plugin = get_addon_name(__FILE__);

if(file_exists($load = addon_path($plugin, "vendor".DS."autoload.php"))){
    require_once $load;
}