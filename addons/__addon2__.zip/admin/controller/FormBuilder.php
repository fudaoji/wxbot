<?php
/**
 * Created by PhpStorm.
 * Script Name: FormBuilder.php
 * Create: 9/21/22 11:11 PM
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace addons\__ADDON_NAME__\admin\controller;


use app\addon\AddonFormBuilder;

class FormBuilder extends AddonFormBuilder
{
    public function initialize()
    {
        parent::initialize();
    }
}