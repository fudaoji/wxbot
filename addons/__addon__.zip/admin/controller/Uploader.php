<?php
/**
 * Created by PhpStorm.
 * Script Name: Uploader.php
 * Create: 2022/12/19 18:01
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace addons\__ADDON_NAME__\admin\controller;


class Uploader extends \app\admin\controller\Uploader
{

}