logo和其他css、js、image等静态资源文件存放此处。
