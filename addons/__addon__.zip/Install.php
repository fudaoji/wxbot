<?php
/**
 * Created by PhpStorm.
 * Script Name: Install.php
 * Create: 2023/5/24 11:40
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace addons\__ADDON_NAME__;

use app\addon\InstallController;

class Install extends InstallController
{
    function install()
    {
        // TODO: Implement install() method.
    }

    function upgrade()
    {
        // TODO: Implement upgrade() method.
    }

    function uninstall()
    {
        // TODO: Implement uninstall() method.
    }
}