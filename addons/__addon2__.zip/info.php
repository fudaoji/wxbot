<?php
/**
 * Created by PhpStorm.
 * Script Name: info.php
 * Create: 2023/5/24 14:01
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

$plugin = get_addon_name(__FILE__);
return [
    'type' => 'wechat',
    'title' => '__ADDON_TITLE__',
    'name' => $plugin,
    'desc' => '__ADDON_DESC__',
    'version' => '__ADDON_VERSION__',
    'depend_wxbot' => '__ADDON_DEPEND_WXBOT__',
    'author' => '__ADDON_AUTHOR__',
    'logo' => '__ADDON_LOGO__',
    'admin_url' => '/addon/'.$plugin.'/admin/index/index',
    'admin_url_type' => 2
];