<?php
/**
 * Created by PhpStorm.
 * Script Name: Index.php
 * Create: 2023/5/23 11:03
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace addons\__ADDON_NAME__\admin\controller;

class Index extends Base
{
    public function welcome(){
        return $this->show();
    }

    public function index(){
        return $this->show();
    }

    /**
     * 获取初始化数据
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     * @author: fudaoji<fdj@kuryun.cn>
     */
    public function getSystemInit(){
        $homeInfo = [
            'title' => '首页',
            'href'  => addon_url('admin/index/welcome'),
        ];
        $logoInfo = [
            'title' => $this->addonInfo['title'],
            'href' => addon_url('admin/index/index'),
            'image' => addon_logo_url($this->addonName),
        ];
        $menuInfo = get_addon_menu($this->addonName);
        $systemInit = [
            'homeInfo' => $homeInfo,
            'logoInfo' => $logoInfo,
            'menuInfo' => $menuInfo,
        ];
        return json($systemInit);
    }
}